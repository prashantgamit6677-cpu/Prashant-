AZIAL STUDIO ALL SERVICES PORTAL — DEMO

Files:
- index.html: responsive Gujarati demo website.

Publish on GitHub Pages:
1. Open your repository: https://github.com/prashantgamit6677-cpu/Prashant-
2. Add/upload index.html at the repository root (same level as README.md).
3. Commit changes to main.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select Branch: main and Folder: /(root), then Save.
7. Wait for deployment. GitHub will show the public website URL in Settings > Pages.

Important:
This is a front-end demo only. Login, registration and applications are stored in the visitor's browser localStorage and are not shared with the studio/admin or across devices. It has no secure server, OTP, database, document upload, payment gateway, or government API connection. Do not collect Aadhaar/PAN scans, OTPs, passwords, or other sensitive data with this demo. For production, build a secure backend with proper authorization and official government integrations.
Demo admin login: 9999999999 / Admin@123 (public demo credentials; never use in production).
